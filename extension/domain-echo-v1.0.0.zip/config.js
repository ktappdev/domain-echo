// Convex configuration
// Get your deployment URL from: npx convex dev
// It will look like: https://happy-animal-123.convex.cloud
const CONFIG = {
  CONVEX_URL: "https://reminiscent-bobcat-176.convex.cloud",
};
