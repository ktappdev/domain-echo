chrome.runtime.onInstalled.addListener(() => {
  console.log('Domain Echo installed');
});
