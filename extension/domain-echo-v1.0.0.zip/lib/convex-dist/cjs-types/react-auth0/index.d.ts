/**
 * React login component for use with Auth0.
 *
 * @module
 */
export { ConvexProviderWithAuth0 } from "./ConvexProviderWithAuth0.js";
//# sourceMappingURL=index.d.ts.map