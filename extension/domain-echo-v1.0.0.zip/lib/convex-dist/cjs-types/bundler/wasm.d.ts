import { PluginBuild } from "esbuild";
export declare const wasmPlugin: {
    name: string;
    setup(build: PluginBuild): void;
};
//# sourceMappingURL=wasm.d.ts.map