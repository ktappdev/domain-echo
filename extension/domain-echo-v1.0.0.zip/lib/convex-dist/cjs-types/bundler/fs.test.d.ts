export {};
//# sourceMappingURL=fs.test.d.ts.map