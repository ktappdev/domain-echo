import { StorageActionWriter, StorageReader, StorageWriter } from "../storage.js";
export declare function setupStorageReader(requestId: string): StorageReader;
export declare function setupStorageWriter(requestId: string): StorageWriter;
export declare function setupStorageActionWriter(requestId: string): StorageActionWriter;
//# sourceMappingURL=storage_impl.d.ts.map