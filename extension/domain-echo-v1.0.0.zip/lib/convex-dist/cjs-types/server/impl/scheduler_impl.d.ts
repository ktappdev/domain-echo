import { Scheduler } from "../scheduler.js";
export declare function setupMutationScheduler(): Scheduler;
export declare function setupActionScheduler(requestId: string): Scheduler;
//# sourceMappingURL=scheduler_impl.d.ts.map