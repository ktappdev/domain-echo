import { Auth } from "../authentication.js";
export declare function setupAuth(requestId: string): Auth;
//# sourceMappingURL=authentication_impl.d.ts.map