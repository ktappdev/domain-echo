export declare function validateArg(arg: any, idx: number, method: string, argName: string): void;
export declare function validateArgIsInteger(arg: any, idx: number, method: string, argName: string): void;
export declare function validateArgIsNonNegativeInteger(arg: any, idx: number, method: string, argName: string): void;
//# sourceMappingURL=validate.d.ts.map