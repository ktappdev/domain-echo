export {};
//# sourceMappingURL=registration.test.d.ts.map