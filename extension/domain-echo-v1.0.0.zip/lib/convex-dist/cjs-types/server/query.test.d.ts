export {};
//# sourceMappingURL=query.test.d.ts.map