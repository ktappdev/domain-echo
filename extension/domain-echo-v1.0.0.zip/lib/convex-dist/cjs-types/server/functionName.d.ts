/**
 * A symbol for accessing the name of a {@link FunctionReference} at runtime.
 */
export declare const functionName: unique symbol;
//# sourceMappingURL=functionName.d.ts.map