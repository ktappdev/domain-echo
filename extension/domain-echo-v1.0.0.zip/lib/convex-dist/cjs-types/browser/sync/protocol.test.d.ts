/**
 * @vitest-environment custom-vitest-environment.ts
 */
export {};
//# sourceMappingURL=protocol.test.d.ts.map