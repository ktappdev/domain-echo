import { Command } from "@commander-js/extra-typings";
export declare const env: Command<[], {
    envFile?: string;
    url?: string;
    adminKey?: string;
    prod?: boolean;
    previewName?: string;
    deploymentName?: string;
}, {}>;
//# sourceMappingURL=env.d.ts.map