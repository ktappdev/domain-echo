import { Command } from "@commander-js/extra-typings";
export declare const init: Command<[], {
    project?: string;
    team?: string;
}, {}>;
//# sourceMappingURL=init.d.ts.map