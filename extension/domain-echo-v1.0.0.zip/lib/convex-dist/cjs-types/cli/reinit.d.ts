import { Command } from "@commander-js/extra-typings";
export declare const reinit: Command<[], {
    team?: string;
    project?: string;
}, {}>;
//# sourceMappingURL=reinit.d.ts.map