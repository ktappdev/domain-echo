import { Command } from "@commander-js/extra-typings";
export declare const docs: Command<[], {
    open: boolean;
}, {}>;
//# sourceMappingURL=docs.d.ts.map