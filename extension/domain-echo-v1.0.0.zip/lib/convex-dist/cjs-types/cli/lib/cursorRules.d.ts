/**
 * If the Cursor rules exist and are out of date, update them.
 */
export declare function autoUpdateCursorRules(expectedRulesHash: string | null): Promise<void>;
//# sourceMappingURL=cursorRules.d.ts.map