import { Context } from "../../bundler/context.js";
export declare function functionSpecForDeployment(ctx: Context, options: {
    deploymentUrl: string;
    adminKey: string;
    file: boolean;
}): Promise<void>;
//# sourceMappingURL=functionSpec.d.ts.map