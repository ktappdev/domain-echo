export declare function hashSha256(value: string): string;
//# sourceMappingURL=hash.d.ts.map