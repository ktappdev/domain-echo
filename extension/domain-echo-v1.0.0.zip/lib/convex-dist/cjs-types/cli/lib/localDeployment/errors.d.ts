export declare class LocalDeploymentError extends Error {
}
export declare function printLocalDeploymentOnError(): void;
//# sourceMappingURL=errors.d.ts.map