import { Command } from "@commander-js/extra-typings";
export declare const mcp: Command<[], {}, {}>;
//# sourceMappingURL=mcp.d.ts.map