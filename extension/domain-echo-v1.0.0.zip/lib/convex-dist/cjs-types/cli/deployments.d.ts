import { Command } from "@commander-js/extra-typings";
export declare const deployments: Command<[], {}, {}>;
//# sourceMappingURL=deployments.d.ts.map