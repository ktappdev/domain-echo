export declare function tsconfigCodegen(): string;
//# sourceMappingURL=tsconfig.d.ts.map