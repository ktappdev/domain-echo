export declare function componentServerTS(isRoot: boolean): string;
//# sourceMappingURL=component_server.d.ts.map