export declare function apiCjsCodegen(modulePaths: string[]): {
    DTS: string | undefined;
    JS: string;
};
//# sourceMappingURL=api_cjs.d.ts.map