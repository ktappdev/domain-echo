export {};
//# sourceMappingURL=ConvexAuthState.test.d.ts.map