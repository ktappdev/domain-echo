export {};
//# sourceMappingURL=auth_websocket.test.d.ts.map