export {};
//# sourceMappingURL=use_paginated_query.test.d.ts.map