export {};
//# sourceMappingURL=queries_observer.test.d.ts.map