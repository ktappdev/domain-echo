/**
 * React login component for use with Clerk.
 *
 * @module
 */
export { ConvexProviderWithClerk } from "./ConvexProviderWithClerk.js";
//# sourceMappingURL=index.d.ts.map