export {};
//# sourceMappingURL=ConvexProviderWithClerk.test.d.ts.map