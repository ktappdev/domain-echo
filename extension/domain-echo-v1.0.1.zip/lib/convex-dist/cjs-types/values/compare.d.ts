import { Value } from "./value.js";
export declare function compareValues(k1: Value | undefined, k2: Value | undefined): number;
//# sourceMappingURL=compare.d.ts.map