export {};
//# sourceMappingURL=size.test.d.ts.map