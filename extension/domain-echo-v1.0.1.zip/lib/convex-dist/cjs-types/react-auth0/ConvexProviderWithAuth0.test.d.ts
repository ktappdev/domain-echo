export {};
//# sourceMappingURL=ConvexProviderWithAuth0.test.d.ts.map