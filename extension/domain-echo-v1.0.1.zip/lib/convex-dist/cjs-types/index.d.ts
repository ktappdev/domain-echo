export declare const version = "1.31.7";
//# sourceMappingURL=index.d.ts.map