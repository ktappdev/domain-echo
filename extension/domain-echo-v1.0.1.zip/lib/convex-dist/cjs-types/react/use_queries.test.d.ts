/**
 * @vitest-environment custom-vitest-environment.ts
 */
export {};
//# sourceMappingURL=use_queries.test.d.ts.map