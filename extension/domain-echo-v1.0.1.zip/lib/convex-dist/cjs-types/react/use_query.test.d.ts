/**
 * @vitest-environment custom-vitest-environment.ts
 */
export {};
//# sourceMappingURL=use_query.test.d.ts.map