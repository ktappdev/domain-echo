export {};
//# sourceMappingURL=use_subscription.d.ts.map