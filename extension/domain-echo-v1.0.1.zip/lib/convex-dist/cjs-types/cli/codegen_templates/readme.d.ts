export declare function readmeCodegen(): string;
//# sourceMappingURL=readme.d.ts.map