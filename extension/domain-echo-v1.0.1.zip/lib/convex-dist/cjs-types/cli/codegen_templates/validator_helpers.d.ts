import { ConvexValidator } from "../lib/deployApi/validator.js";
export declare function parseValidator(validator: string | null): ConvexValidator | null;
export declare function validatorToType(validator: ConvexValidator, useIdType: boolean): string;
//# sourceMappingURL=validator_helpers.d.ts.map