import { Command } from "@commander-js/extra-typings";
export declare const logout: Command<[], {}, {}>;
//# sourceMappingURL=logout.d.ts.map