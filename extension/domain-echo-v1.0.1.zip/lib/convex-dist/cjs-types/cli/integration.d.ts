/**
 * Debugging commands for the WorkOS integration; these are unstable, undocumented, and will change or disappear as the WorkOS integration evolves.
 **/
import { Command } from "@commander-js/extra-typings";
export declare const integration: Command<[], {}, {}>;
//# sourceMappingURL=integration.d.ts.map