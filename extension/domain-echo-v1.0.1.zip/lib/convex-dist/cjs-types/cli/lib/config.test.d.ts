export {};
//# sourceMappingURL=config.test.d.ts.map