export declare function readFromStdin(): Promise<string>;
//# sourceMappingURL=stdin.d.ts.map