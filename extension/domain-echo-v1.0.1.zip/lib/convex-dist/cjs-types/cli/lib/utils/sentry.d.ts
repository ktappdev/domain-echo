import "@sentry/tracing";
export declare const SENTRY_DSN = "https://f9fa0306e3d540079cf40ce8c2ad9644@o1192621.ingest.sentry.io/6390839";
export declare function initSentry(): void;
//# sourceMappingURL=sentry.d.ts.map