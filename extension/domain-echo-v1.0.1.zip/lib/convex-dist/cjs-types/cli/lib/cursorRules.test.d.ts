export {};
//# sourceMappingURL=cursorRules.test.d.ts.map