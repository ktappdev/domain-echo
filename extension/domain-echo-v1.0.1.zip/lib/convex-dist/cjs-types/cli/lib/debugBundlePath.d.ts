import { Context } from "../../bundler/context.js";
import { Config } from "./config.js";
export declare function handleDebugBundlePath(ctx: Context, debugBundleDir: string, config: Config): Promise<undefined>;
//# sourceMappingURL=debugBundlePath.d.ts.map