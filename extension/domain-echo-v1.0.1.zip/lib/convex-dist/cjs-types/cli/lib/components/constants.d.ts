export declare const DEFINITION_FILENAME_TS = "convex.config.ts";
export declare const DEFINITION_FILENAME_JS = "convex.config.js";
//# sourceMappingURL=constants.d.ts.map