/**
 * Check the version of the `convex` NPM package and automatically update Cursor
 * rules if applicable.
 */
export declare function checkVersion(): Promise<void>;
//# sourceMappingURL=updates.d.ts.map