import { Context } from "../../bundler/context.js";
export declare function usageStateWarning(ctx: Context, targetDeployment: string): Promise<void>;
//# sourceMappingURL=usage.d.ts.map