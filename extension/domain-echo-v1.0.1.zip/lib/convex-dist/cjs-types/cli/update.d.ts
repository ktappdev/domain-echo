import { Command } from "@commander-js/extra-typings";
export declare const update: Command<[], {}, {}>;
//# sourceMappingURL=update.d.ts.map