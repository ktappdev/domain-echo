export declare const version: string;
//# sourceMappingURL=version.d.ts.map