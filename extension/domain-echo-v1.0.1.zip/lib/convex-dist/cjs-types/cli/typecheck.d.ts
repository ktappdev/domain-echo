import { Command } from "@commander-js/extra-typings";
export type TypecheckResult = "cantTypeCheck" | "success" | "typecheckFailed";
/** Run the TypeScript compiler, as configured during  */
export declare const typecheck: Command<[], {
    typescriptCompiler?: "tsc" | "tsgo";
}, {}>;
//# sourceMappingURL=typecheck.d.ts.map