import { Command } from "@commander-js/extra-typings";
export declare const auth: Command<[], {}, {}>;
//# sourceMappingURL=auth.d.ts.map