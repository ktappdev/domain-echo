import { Command } from "@commander-js/extra-typings";
export declare const disableLocalDeployments: Command<[], {
    global?: true;
    undoGlobal?: true;
}, {}>;
//# sourceMappingURL=disableLocalDev.d.ts.map