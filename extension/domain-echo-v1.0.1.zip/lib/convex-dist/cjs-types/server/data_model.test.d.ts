export {};
//# sourceMappingURL=data_model.test.d.ts.map