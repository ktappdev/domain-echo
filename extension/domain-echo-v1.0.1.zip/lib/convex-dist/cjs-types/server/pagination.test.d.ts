export {};
//# sourceMappingURL=pagination.test.d.ts.map