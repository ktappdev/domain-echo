export {};
//# sourceMappingURL=paginated_query_client.test.d.ts.map