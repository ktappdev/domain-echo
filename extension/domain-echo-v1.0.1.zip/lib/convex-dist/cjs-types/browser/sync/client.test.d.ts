/**
 * @vitest-environment custom-vitest-environment.ts
 */
export {};
//# sourceMappingURL=client.test.d.ts.map