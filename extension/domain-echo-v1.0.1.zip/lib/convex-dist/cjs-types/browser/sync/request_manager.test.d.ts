export {};
//# sourceMappingURL=request_manager.test.d.ts.map