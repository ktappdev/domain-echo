export declare function newSessionId(): string;
//# sourceMappingURL=session.d.ts.map