import { ConvexClient } from "./simple_client.js";
export { ConvexClient };
//# sourceMappingURL=simple_client-node.d.ts.map