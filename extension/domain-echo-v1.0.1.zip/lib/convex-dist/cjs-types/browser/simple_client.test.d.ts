export {};
//# sourceMappingURL=simple_client.test.d.ts.map